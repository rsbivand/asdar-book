###################################################
### chunk number 1: 
###################################################
rm(list=ls())
if ((site <- Sys.getenv("ASDAR_DOWNLOAD")) != "") {
  download.file(paste(site, "NY_data.zip", sep="/"), "NY_data.zip")
}

###################################################
### chunk number 8: 
###################################################
fname <- zip.file.extract(file="NY8_utm18.dbf", zipname = "NY_data.zip")
file.copy(fname, "./NY8_utm18.dbf", overwrite=TRUE)
fname <- zip.file.extract(file="NY8_utm18.prj", zipname = "NY_data.zip")
file.copy(fname, "./NY8_utm18.prj", overwrite=TRUE)
fname <- zip.file.extract(file="NY8_utm18.shp", zipname = "NY_data.zip")
file.copy(fname, "./NY8_utm18.shp", overwrite=TRUE)
fname <- zip.file.extract(file="NY8_utm18.shx", zipname = "NY_data.zip")
file.copy(fname, "./NY8_utm18.shx", overwrite=TRUE)

library(sp)
library(rgdal)
NY8 <- readOGR(".", "NY8_utm18")


###################################################
### chunk number 15: 
###################################################
Syracuse <- NY8[NY8$AREANAME == "Syracuse city",]



###################################################
### chunk number 17: 
###################################################
library(spdep)
Sy2_nb <- poly2nb(Syracuse, queen=FALSE)
Sy2_nb


###################################################
### chunk number 19:  eval=FALSE
###################################################
library(spgrass6)
writeVECT6(Syracuse, "SY0")
contig <- vect2neigh("SY0")


###################################################
### chunk number 21: 
###################################################
Sy3_nb <- sn2listw(contig)$neighbours
Sy3_nb
isTRUE(all.equal(Sy3_nb, Sy2_nb, check.attributes=FALSE))



