coverage2nb <- function(ARC, IDs, iIDs, oIDs) {
# ARC SpatialLinesDataFrame from AVCBin driver, layer: "ARC"
# IDs character vector from AVCBin driver, layer: "PAL"
# IDs integer vector from AVCBin driver, layer: "PAL"
# oIDs character vector of Polygons ID slots following unionSpatialPolygons
    if (!is(ARC, "SpatialLinesDataFrame")) stop("not a SpatialLinesDataFrame")
    o <- match(IDs, oIDs)
    x <- c(ARC$LPOLY_, ARC$RPOLY_)
    y <- c(ARC$RPOLY_, ARC$LPOLY_)
    xy <- cbind(x, y)
    is.na(xy) <- xy == 1
    xy1 <- xy[complete.cases(xy),]
    xy2 <- cbind(match(xy1[,1], iIDs), match(xy1[,2], iIDs))
    xy3 <- cbind(o[xy2[,1]], o[xy2[,2]])
    res <- tapply(xy3[,2], xy3[,1], c)
    res <- lapply(res, function(x) unlist(ifelse(length(x) == 0,
        list(as.integer(0)), list(x))))
    res <- lapply(res, function(x) as.integer(unique(sort(x))))
    names(res) <- NULL
	class(res) <- "nb"
    attr(res, "region.id") <- oIDs
    attr(res, "sym") <- is.symmetric.nb(res, verbose=FALSE)
    res
}
 