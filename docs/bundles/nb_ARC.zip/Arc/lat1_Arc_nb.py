# chunk 1

import os, sys
import locale
cur_LC = locale.setlocale(locale.LC_ALL, '')
from win32com.client import Dispatch
GP = Dispatch('esriGeoprocessing.GpDispatch.1')

GP.workspace = os.getcwd()
print GP.workspace
GP.OverwriteOutput = 1
cur_LC = locale.setlocale(locale.LC_ALL, '')

# chunk 2

in_feat = os.getcwd() + '\\Syracuse.shp polygon'
out_cov = 'Syr_Cov1'
SY = GP.FeatureClassToCoverage_conversion(in_feat, out_cov)
print SY
syracuse = out_cov

# chunk 10
'''
note
before using this code start 
the editor pythonwin - part of win32all 
select Tools menu
select COM MakePy utility
select StatConnectorSrv *.* type library 
  *.* will vary - its the version number
hit OK - 

this process will generate python code that allows the 
correct conversion of python data types into
com data types for the RDCOM interface
'''

# initialize R
print "Initialising R ..."
R = Dispatch('StatConnectorSrv.StatConnector')
R.Init('R')

r_libs = "C:/Program Files/r_libs" # arg

print "Loading R packages ..."
R.EvaluateNoReturn('.libPaths("%s")' % r_libs)
R.EvaluateNoReturn('library(sp)')
R.EvaluateNoReturn('library(rgdal)')
R.SetSymbol('syracuse', os.getcwd() + "/" + syracuse)
print R.GetSymbol('syracuse')

#  chunk 11

cmd = 'capture.output(sessionInfo())'
res = R.Evaluate(cmd)
print str(res[0])

# chunk 12

cmd1 = 'readOGR(dsn=syracuse, layer='
cmd2 = 'drop_unsupported_fields=TRUE)'
cmd = cmd1 + '\"PAL\", ' + cmd2
R.EvaluateNoReturn('sy <- %s' % cmd)
print R.Evaluate('class(sy)')

# chunk 13

wcmd = 'ifelse (exists(\"last.warning\"), '
wcmd = wcmd + 'capture.output(print(last.warning)), '
wcmd = wcmd + '\"None\")'
print str(R.Evaluate('%s' % wcmd))

# chunk 14

print R.Evaluate('length(slot(sy, "polygons"))')
print R.Evaluate('names(sy)')
print R.Evaluate('length(unique(sy$AREAKEY))')

#  chunk 15

cmd = cmd1 + '\"ARC\", ' + cmd2
R.EvaluateNoReturn('sy_arc <- %s' % cmd)
print R.Evaluate('class(sy_arc)')
print R.Evaluate('names(sy_arc)')

# chunk 16

cmd = 'IDs <- as.character(sy$AREAKEY)'
R.EvaluateNoReturn('%s' % cmd)
R.EvaluateNoReturn('iIDs <- sy$SYR_COV1.ID')

# chunk 17

R.EvaluateNoReturn('library(maptools)')
R.EvaluateNoReturn('library(gpclib)')
R.EvaluateNoReturn('syp <- as(sy, \"SpatialPolygons\")')
R.EvaluateNoReturn('USP <- unionSpatialPolygons(syp, IDs=IDs)')
R.EvaluateNoReturn('pls <- slot(USP, \"polygons\")')
cmd = 'function(x) slot(x, "ID")'
R.EvaluateNoReturn('oIDs <- sapply(pls, %s)' % cmd)

# chunk 18

R.EvaluateNoReturn('library(spdep)')
R.EvaluateNoReturn('nb_poly <- poly2nb(USP, queen=FALSE)')
res = R.Evaluate('capture.output(print(nb_poly))')
for i in res:
    print str(i)

# chunk 19

src = os.getcwd() + '/coverage2nb.R'
R.SetSymbol('src', src)
R.EvaluateNoReturn('source(src)')
cmd = 'nb_cov <- '
cmd = cmd + 'coverage2nb(sy_arc, IDs, iIDs, oIDs)'
R.EvaluateNoReturn('%s' % cmd)
res1 = R.Evaluate('capture.output(print(nb_cov))')
for i in res1:
    print str(i)

# chunk 24

print "closing R ..."
R.Close()
del(R)
del(GP)

